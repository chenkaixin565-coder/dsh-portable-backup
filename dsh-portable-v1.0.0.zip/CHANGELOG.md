# Changelog

## 1.0.0 — 2026-10-18

首个公开版本。

### 功能

- 整库备份为文件夹或 ZIP：`sessions/`、`attachments/`、`storages/workspace.json`，可选 `profiles/` 和 `.credentials.yaml`。
- 整库恢复：合并或替换模式；自动把旧 Windows 用户目录映射到新用户目录；同 ID 会话默认跳过。
- 导入官方 `/export` 会话 ZIP：根会话、子会话、图片、通用文件；支持 `--workspace` 指定目标工作区。
- 中文交互菜单；也可用子命令脚本化。
- 复用 DSH 自带的 Node 运行时，无需安装第三方依赖。
- 恢复/导入后把 `workspace.json` 的 `initialized` 置为 `false`，由 DSH 自己重新分组。
- 默认不备份/恢复凭据。

### 验证

- DSH `0.2.0-rc.2`，Windows 11，会话格式 v4。
- 11 个真实会话、137 个附件：备份/恢复到临时 `DSH_HOME`，逐会话校验事件数、`seq` 连续性、`cwd` 重映射。
- 用临时 `DSH_HOME` 启动 `dsh web`，确认 11 个会话自动注册、无重复归属错误。
- 官方格式 ZIP：39 张图片、子会话、中文文件名通用文件导入通过。

### 已知限制

- 只提供 Windows `.cmd` 启动器；其他平台未验证。
- 不支持实时云同步；请搭配 `dsh-backup`、WebDAV 或 git 同步插件。
- DSH 未运行时才能安全恢复/导入；`--force` 仅用于明确知道后果的场景。
- 会话格式若在未来大版本变化，可能需要更新导入器。
