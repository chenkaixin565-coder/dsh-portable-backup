# 发布到 Gitee

本目录已经是一个可发布的仓库内容（README、LICENSE、CHANGELOG、SECURITY、docs、可执行工具）。下面以仓库名 `dsh-portable` 为例。

## 1. 在 Gitee 创建仓库

1. 登录 Gitee，右上角 **+ → 新建仓库**。
2. 仓库名：`dsh-portable`。
3. 路径：`https://gitee.com/<你的用户名>/dsh-portable`。
4. 可见性：公开（想先私有也可以）。
5. **不要**勾选“使用 Readme 初始化”，否则首次 push 需要先 pull。
6. 语言/主题可填：`Node.js`、`Windows`、`DeepSeek`、`备份`、`迁移`。

## 2. 本机安装 Git（如果还没有）

Windows 推荐：

```powershell
winget install --id Git.Git -e --source winget
```

或从 [git-scm.com](https://git-scm.com/download/win) 下载安装。安装后重开终端，确认：

```powershell
git --version
```

## 3. 初始化并推送

在本目录执行：

```powershell
cd dsh-portable

git init -b main
git config user.name "你的名字"
git config user.email "你的邮箱"

git add .
git commit -m "feat: dsh-portable v1.0.0"

git remote add origin https://gitee.com/<你的用户名>/dsh-portable.git
git push -u origin main
```

如果 Gitee 要求登录，使用账号密码/私人令牌；不要把令牌写进仓库。

## 4. 发布 Release

1. 先构建发布包：

   ```powershell
   powershell -ExecutionPolicy Bypass -File scripts\pack.ps1
   ```

   生成 `dist\dsh-portable-v1.0.0.zip`。

2. Gitee 仓库页 → **发行版 → 创建发行版**：
   - 版本号：`v1.0.0`
   - 标题：`dsh-portable v1.0.0`
   - 描述：可直接粘贴 `CHANGELOG.md` 的 1.0.0 段。
   - 附件：上传 `dist\dsh-portable-v1.0.0.zip`。

3. 下载页用户解压后双击 `dsh-portable.cmd` 即可。

> `dist/` 已在 `.gitignore` 中忽略；发布包作为 Release 附件上传，不要提交进 Git。

## 5. 仓库设置建议

- **简介**：`不装插件、双击即用的 DeepSeek Harness 会话备份/恢复/迁移工具（Windows）`
- **Topics**：`deepseek` `deepseek-harness` `dsh` `backup` `restore` `migration` `windows` `portable`
- **开源许可证**：MIT（已包含 `LICENSE`）
- **Issue 模板**：可加“环境 / 复现步骤 / 日志”三项。
- **README 首屏**：已经包含“非官方”“先备份”“和现有插件对比”的说明。

## 6. 不要提交的内容

`.gitignore` 已忽略：

- `dsh-backup-*`、`*.zip`、`dist/`
- `_test-*`、`tmp/`、`*.log`
- `node_modules/`
- `.credentials.yaml`、`.dsh/`

提交前仍建议执行：

```powershell
git status
git diff --cached
```

确认没有把真实会话、附件、凭据、本机路径带进去。

## 7. 后续更新

```powershell
git add .
git commit -m "fix: ..."
git push
```

发新版本时：

1. 改 `package.json` 的 `version`；
2. 在 `CHANGELOG.md` 增加一段；
3. 重新运行 `scripts\pack.ps1`；
4. 在 Gitee 创建新的 Release 并上传 ZIP。

## 8. 可选：镜像到 GitHub

Gitee 支持从 GitHub 导入仓库；也可以本地加两个 remote：

```powershell
git remote add github https://github.com/<你的用户名>/dsh-portable.git
git push github main
```

不要在两个平台分别手改代码，保持一个主仓库，另一个只做镜像。
